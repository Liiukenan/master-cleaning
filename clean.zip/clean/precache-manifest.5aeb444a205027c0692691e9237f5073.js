self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "51b306d3912ef53e0586c09aa6d79e8c",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "8923cfa71b48ee3aa44f",
    "url": "./static/css/main.fda2cd76.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8923cfa71b48ee3aa44f",
    "url": "./static/js/main.5fe4bcb1.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "90558164288d2dc4d1725b392c9589df",
    "url": "./static/media/bg_head.90558164.png"
  },
  {
    "revision": "b16a8e2d847f47ebdc9c0b64346c3c1b",
    "url": "./static/media/img_head.b16a8e2d.png"
  },
  {
    "revision": "28af80e0f05330d5ab69d5819941bb30",
    "url": "./static/media/phone_boost.28af80e0.png"
  },
  {
    "revision": "0749119f614d74ed01f6cfc8d8d59c2c",
    "url": "./static/media/phone_rubbishclean.0749119f.png"
  },
  {
    "revision": "303b9ad6018660b41cb9019afbfc7e9b",
    "url": "./static/media/phone_wechatclean.303b9ad6.png"
  }
]);