self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4f46e70b35d700d87ce4e09cd5780a86",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "ae55af7da74a1c706b62",
    "url": "./static/css/main.2e70e1a7.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ae55af7da74a1c706b62",
    "url": "./static/js/main.8a9bd592.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "d0a5f3e800dec2852758e6f94dcac18d",
    "url": "./static/media/bg_head.d0a5f3e8.png"
  },
  {
    "revision": "9e02674c91e09f50eb6a1c202cdce652",
    "url": "./static/media/img_head.9e02674c.png"
  },
  {
    "revision": "cf5f7df5ece2d40e1bf11590251fa3cf",
    "url": "./static/media/phone_boost.cf5f7df5.png"
  },
  {
    "revision": "836e0345332e0a3cdbfa322898da0a81",
    "url": "./static/media/phone_rubbishclean.836e0345.png"
  },
  {
    "revision": "21c83faf0ddc7541f849f69d976e26a2",
    "url": "./static/media/phone_wechatclean.21c83faf.png"
  }
]);