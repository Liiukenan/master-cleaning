self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d07b7512139a6c02598b55b791b47ec0",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "40a716581fa32c067c0c",
    "url": "./static/css/main.381dc1f2.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "40a716581fa32c067c0c",
    "url": "./static/js/main.c430e7fe.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "90558164288d2dc4d1725b392c9589df",
    "url": "./static/media/bg_head.90558164.png"
  },
  {
    "revision": "8493de8c9016a7601989da9ce497869e",
    "url": "./static/media/img_head.8493de8c.png"
  },
  {
    "revision": "8f549ed9ba7fa0212b1ed3bbed0c6816",
    "url": "./static/media/phone_boost.8f549ed9.png"
  },
  {
    "revision": "8d03595fd1c9db2be865f66b6495f94c",
    "url": "./static/media/phone_rubbishclean.8d03595f.png"
  },
  {
    "revision": "08d6b51029cc6127e89cbebb69f0e5fb",
    "url": "./static/media/phone_wechatclean.08d6b510.png"
  }
]);