self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0cb04dcf598c737469545bc91cbe6e59",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "6d64e678bddf871b00c0",
    "url": "./static/css/main.995e5b85.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6d64e678bddf871b00c0",
    "url": "./static/js/main.2afefe69.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "90558164288d2dc4d1725b392c9589df",
    "url": "./static/media/bg_head.90558164.png"
  },
  {
    "revision": "d65271180811aa884b715c6e72cf565e",
    "url": "./static/media/img_head.d6527118.png"
  },
  {
    "revision": "c71444793692b116ec24806a60bcb2c7",
    "url": "./static/media/phone_boost.c7144479.png"
  },
  {
    "revision": "2d3d56abc341cb4920067d83ea36ce98",
    "url": "./static/media/phone_rubbishclean.2d3d56ab.png"
  },
  {
    "revision": "252aa963eec3c7bc6864149d27aa0cfc",
    "url": "./static/media/phone_wechatclean.252aa963.png"
  }
]);