self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "deae74b18a2c9b8e02c916cd56191ced",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "35382a89fb44082fce0d",
    "url": "./static/css/main.4bff7665.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "35382a89fb44082fce0d",
    "url": "./static/js/main.3f9e83cf.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "d0a5f3e800dec2852758e6f94dcac18d",
    "url": "./static/media/bg_head.d0a5f3e8.png"
  },
  {
    "revision": "bc0bf6de70936cd339e99787646a7bba",
    "url": "./static/media/img_head.bc0bf6de.png"
  },
  {
    "revision": "4fbd102f2cb130af6e12c25dcdf8919a",
    "url": "./static/media/logo.4fbd102f.png"
  },
  {
    "revision": "1d0a8284c28f69d110f00eec0f5687c8",
    "url": "./static/media/phone_boost.1d0a8284.png"
  },
  {
    "revision": "8564d58ba670c9eae4a7e9e59e5f5264",
    "url": "./static/media/phone_rubbishclean.8564d58b.png"
  },
  {
    "revision": "d71487222a69c41bfe099c071584347c",
    "url": "./static/media/phone_wechatclean.d7148722.png"
  }
]);