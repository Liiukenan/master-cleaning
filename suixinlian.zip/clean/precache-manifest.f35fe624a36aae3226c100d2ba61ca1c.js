self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c83dd8651039813330eb7d86ecb1128e",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "f9b0691a73873939a092",
    "url": "./static/css/main.2d6fdf9c.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f9b0691a73873939a092",
    "url": "./static/js/main.f0bb37d8.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "90558164288d2dc4d1725b392c9589df",
    "url": "./static/media/bg_head.90558164.png"
  },
  {
    "revision": "ae71e5368037aabeb4594d7c8c219caa",
    "url": "./static/media/ic_rubbishclean.ae71e536.png"
  },
  {
    "revision": "009f43b38dc68c3945f6b2a8735791a8",
    "url": "./static/media/ic_wechatclean.009f43b3.png"
  },
  {
    "revision": "7d29b3eda9638caa94659c80a70ff549",
    "url": "./static/media/img_head.7d29b3ed.png"
  },
  {
    "revision": "b7479598e6219442a4117801dc64d194",
    "url": "./static/media/phone_boost.b7479598.png"
  },
  {
    "revision": "a3b134b27d19b817b914c93a2755fb04",
    "url": "./static/media/phone_rubbishclean.a3b134b2.png"
  },
  {
    "revision": "354b333aa6d4aefb3326e48529a5e267",
    "url": "./static/media/phone_wechatclean.354b333a.png"
  }
]);