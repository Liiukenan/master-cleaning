self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8234f485afd4c57442156e180124d58d",
    "url": "./index.html"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/css/2.b0169879.chunk.css"
  },
  {
    "revision": "8d377812c7626225a1d6",
    "url": "./static/css/main.6299ebb8.chunk.css"
  },
  {
    "revision": "d3c24f353f353f924fbe",
    "url": "./static/js/2.6f952cd9.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.6f952cd9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8d377812c7626225a1d6",
    "url": "./static/js/main.454cb603.chunk.js"
  },
  {
    "revision": "2b00759073bc710e4949",
    "url": "./static/js/runtime-main.1ce6add8.js"
  },
  {
    "revision": "90558164288d2dc4d1725b392c9589df",
    "url": "./static/media/bg_head.90558164.png"
  },
  {
    "revision": "ae71e5368037aabeb4594d7c8c219caa",
    "url": "./static/media/ic_rubbishclean.ae71e536.png"
  },
  {
    "revision": "009f43b38dc68c3945f6b2a8735791a8",
    "url": "./static/media/ic_wechatclean.009f43b3.png"
  },
  {
    "revision": "71b4d39fba44f96540fb3fcee66e3212",
    "url": "./static/media/img_head.71b4d39f.png"
  },
  {
    "revision": "9ed965d4464eeedb6e48692294864e6c",
    "url": "./static/media/phone_boost.9ed965d4.png"
  },
  {
    "revision": "58918cbf7a667ba7d116cf1a5720bb11",
    "url": "./static/media/phone_rubbishclean.58918cbf.png"
  },
  {
    "revision": "a96e76da55ab0b5851aa625cafd3c22f",
    "url": "./static/media/phone_wechatclean.a96e76da.png"
  }
]);